<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Auth;
class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        if (Auth::check()) {
            $student_id = Auth::user()->user_name;
            $item_list = DB::table('tbl_item_name')->select('*')->get();
            $notice_list = DB::table('tbl_notice')->select('*')->limit(1)->orderBy('id','desc')->first();
            $branch_summery = DB::table('tbl_item_distribution')
                ->join('tbl_item', 'tbl_item.id', '=', 'tbl_item_distribution.item_id')
                ->join('tbl_item_name', 'tbl_item_name.id', '=', 'tbl_item_distribution.item_name_id')
                ->join('tbl_brand', 'tbl_brand.id', '=', 'tbl_item.brand_id')
                ->join('tbl_region', 'tbl_region.id', '=', 'tbl_item_distribution.region_id')
                ->join('tbl_zone', 'tbl_zone.id', '=', 'tbl_item_distribution.zone_id')
                ->join('tbl_branch', 'tbl_branch.id', '=', 'tbl_item_distribution.branch_id')
                ->where('tbl_item_distribution.distribution_type','=', 'Branch')
                ->where('tbl_item.recycle', '=', 0)
                ->where('tbl_item_distribution.diff', '!=', '0')
                ->groupBy('tbl_item_distribution.item_name_id')
                ->select('tbl_item.*', 'tbl_item_distribution.*','tbl_item_name.item_name','tbl_branch.branch_name', 'tbl_branch.phone', 'tbl_zone.zone_name', 'tbl_brand.brand_name', 'tbl_region.region_name', DB::raw('sum(distribution_qty) as distribution_qty'))
                ->get();
            $head_office_summery = DB::table('tbl_item_distribution')
                ->join('tbl_item', 'tbl_item.id', '=', 'tbl_item_distribution.item_id')
                ->join('tbl_item_name', 'tbl_item_name.id', '=', 'tbl_item_distribution.item_name_id')
                ->join('tbl_brand', 'tbl_brand.id', '=', 'tbl_item.brand_id')
                ->join('tbl_employee', 'tbl_employee.id', '=', 'tbl_item_distribution.emp_id')
                ->join('tbl_employee_department', 'tbl_employee_department.id', '=', 'tbl_employee.department_id')
                ->where('tbl_item_distribution.distribution_type','Head office')
                ->where('tbl_item_distribution.diff', '!=', '0')
                ->where('tbl_item.recycle', '=', 0)
                ->whereColumn('tbl_item_distribution.distribution_qty', '!=', 'tbl_item_distribution.distribution_recycle_qty')
                ->groupBy('tbl_item_distribution.item_name_id')
                ->select('tbl_item.*', 'tbl_brand.brand_name', 'tbl_item_distribution.*',
                    'tbl_employee.employee_name','tbl_employee.employee_id','tbl_item_name.item_name','tbl_employee_department.department_name', DB::raw('sum(distribution_qty) as distribution_qty'))
                ->get();

            $project_summery = DB::table('tbl_item_distribution')
                ->join('tbl_item', 'tbl_item.id', '=', 'tbl_item_distribution.item_id')
                ->join('tbl_item_name', 'tbl_item_name.id', '=', 'tbl_item_distribution.item_name_id')
                ->join('tbl_brand', 'tbl_brand.id', '=', 'tbl_item.brand_id')
                ->join('tbl_project', 'tbl_project.id', '=', 'tbl_item_distribution.project_id')
                ->join('tbl_branch', 'tbl_branch.id', '=', 'tbl_item_distribution.branch_id')
                ->where('tbl_item_distribution.distribution_type','Project')
                ->where('tbl_item.recycle', '=', 0)
                ->where('tbl_item_distribution.diff', '!=', '0')
                ->groupBy('tbl_item_distribution.item_name_id')
                ->select('tbl_item.*', 'tbl_item_distribution.*','tbl_item_name.item_name','tbl_branch.branch_name', 'tbl_project.project_name', 'tbl_brand.brand_name', DB::raw('sum(distribution_qty) as distribution_qty'))
                ->get();
            return view('admin/dashboard', compact('item_list','notice_list', 'branch_summery', 'head_office_summery', 'project_summery'));
        }
        else {
            return view('signin');
        }
    }

}

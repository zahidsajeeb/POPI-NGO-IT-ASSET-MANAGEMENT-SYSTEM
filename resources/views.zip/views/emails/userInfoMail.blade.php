<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
<h5>Your User ID: <b>{{ $details['student_id'] }}</b></h5>
<h5>Password:  <b>{{ $details['password'] }}</b> </h5>
<p> Please Visit this link for login : <b>{{ $details['link'] }}</b></p>
<p>Thank you</p>
</body>
</html>

<meta name="author" content="">
<meta name="description" content="">
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>:: Escort - Job Portal HTML Template ::</title>
<link rel="shortcut icon" href="assets/img/favicon.png"/>
<!-- CSS -->
<link rel="stylesheet" href="{{asset('frontend/assets/plugins/bootstrap/css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/plugins/bootstrap/css/bootstrap-select.min.css')}}">
<link href="{{asset('frontend/assets/plugins/icons/css/icons.css')}}" rel="stylesheet">
<link href="{{asset('frontend/assets/plugins/animate/animate.css')}}" rel="stylesheet">
<link href="{{asset('frontend/assets/plugins/bootstrap/css/bootsnav.css')}}" rel="stylesheet">
<link rel="stylesheet" href="{{asset('frontend/assets/plugins/nice-select/css/nice-select.css')}}">
<link href="{{asset('frontend/assets/plugins/aos-master/aos.css')}}" rel="stylesheet">
<link href="{{asset('frontend/assets/css/style.css')}}" rel="stylesheet">
<link href="{{asset('frontend/assets/css/responsive.css')}}" rel="stylesheet">
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600&amp;display=swap" rel="stylesheet">

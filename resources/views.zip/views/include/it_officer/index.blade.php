<div class="page-content">
    <div class="content-wrapper">
        <div class="content-inner">
            <div class="page-header page-header-light">
                <div class="page-header-content header-elements-lg-inline">
                    <div class="page-title d-flex">
                        <h4><i class="icon-home"></i> <span class="font-weight-semibold"></span>Welcome To POPI SOFTWARE</h4>
                    </div>
                </div>
            </div>
            <div class="content">
{{--                @if($notice_list)--}}
{{--                    <div class="row">--}}
{{--                        <div class="col-md-12">--}}
{{--                            <div class="alert alert-info alert-dismissible">--}}
{{--                                <h3><b>Notice:</b></h3>--}}
{{--                                <span class="font-weight-semibold">{{$notice_list->notice}}</span>.--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                @endif--}}
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card card-body border-top-info">
                            <div class="text-center">
                                <h6 class="font-weight-semibold mb-0">Toner Purchase Request</h6>
                                <p class="mb-3 text-muted">Specify target in <code>href</code> attribute</p>

                                <a class="btn btn-primary" href="{{url('other/toner_purchase')}}">
                                    Ckick Here
                                </a>
                            </div>

                            <div class="collapse" id="collapse-link-collapsed">
                                <div class="mt-3">

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card card-body border-top-info">
                            <div class="text-center">
                                <h6 class="font-weight-semibold mb-0">Branch/Project Working/Visiting Form</h6>
                                <p class="mb-3 text-muted">Specify target in <code>href</code> attribute</p>

                                <a class="btn btn-primary" href="{{url('other/visiting_working_info')}}">
                                    Ckick Here
                                </a>
                            </div>

                            <div class="collapse" id="collapse-link-collapsed">
                                <div class="mt-3">

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card card-body border-top-info">
                            <div class="text-center">
                                <h6 class="font-weight-semibold mb-0">Purchase Request Form</h6>
                                <p class="mb-3 text-muted">Specify target in <code>href</code> attribute</p>

                                <a class="btn btn-primary" href="{{url('other/purchase_request')}}">
                                    Ckick Here
                                </a>
                            </div>

                            <div class="collapse" id="collapse-link-collapsed">
                                <div class="mt-3">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


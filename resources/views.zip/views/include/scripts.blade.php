<script src="{{asset('frontend/assets/js/jquery.min.js')}}"></script>
<script src="{{asset('frontend/assets/plugins/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('frontend/assets/plugins/bootstrap/js/bootsnav.js')}}"></script>
<script src="{{asset('frontend/assets/js/viewportchecker.js')}}"></script>
<script src="{{asset('frontend/assets/js/slick.js')}}"></script>
<script src="{{asset('frontend/assets/plugins/bootstrap/js/wysihtml5-0.3.0.js')}}"></script>
<script src="{{asset('frontend/assets/plugins/bootstrap/js/bootstrap-wysihtml5.js')}}"></script>
<script src="{{asset('frontend/assets/plugins/aos-master/aos.js')}}"></script>
<script src="{{asset('frontend/assets/plugins/nice-select/js/jquery.nice-select.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/custom.js')}}"></script>
<script>
    $(window).load(function() {
        $(".page_preloader").fadeOut("slow");;
    });
    AOS.init();
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    @include('admin.include.stylesheet')
    <style>
        .error {
            color: red;
            font-weight: bold;
        }

        .card {
            border-radius: 0px !important;
            border-color: #604c4c69 !important;
        }

        input {
            border-radius: 0px !important;
            border-color: #604c4c69 !important;
        }
    </style>
</head>
<body>
@include('admin.include.navbar')
<div class="page-content">
    @include('admin.include.sidebar')
    <div class="content-wrapper">
        <div class="content-inner">
            <div class="page-header page-header-light">
                <div class="page-header-content header-elements-lg-inline">
                    <div class="page-title d-flex">
                        <h4><i class="icon-home"></i> <span class="font-weight-semibold">Home</span> - Item Show</h4>
                    </div>
                    <div class="navbar-right">
                        <a href="{{url('item')}}" class="btn btn-danger navbar-right" style="border-radius:0px;"><i class="fa fa-backward"></i> Back To Previous Page</a>
                        <button class="btn btn-primary navbar-right" onclick="printDiv('printableArea')" style="border-radius:0px;"><i class="fa fa-print"></i> Print</button>
                    </div>
                </div>
            </div>
            <div class="content">
                <div class="row">
                    <div class="col-md-12" id="printableArea">
                        <div class="card">
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <tr>
                                        <td><img src="{{url('backend/global_assets/images/logo.jpg')}}" style="height:50px;width:120px;"></td>
                                        <td colspan="3" style="text-align:center;">
                                            <h2>People's Oriented Program Implementation</h2>
                                            <span>House#5/11-A, Block#E, Lalmatia, Dhaka-1207, Bangladesh.</span><br>
                                            <span><b>Phone:</b>9121049.  <b>E-mail:</b> popi@bdmail.com, info@popibd.org. <b>Website:</b> www.popibd.org</span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="background: #80808026; color: black;"><b>Employee ID</b></td>
                                        <td><p>{{$data->employee_id}}</p></td>
                                        <td style="background: #80808026; color: black;"><b>Employee Name</b></td>
                                        <td><p>{{$data->employee_name}}</p></td>
                                    </tr>
                                    <tr>
                                        <td style="background: #80808026; color: black;"><b>Department</b></td>
                                        <td style="width:30%"><p>{{$dept_name->department_name}}</p></td>
                                        <td style="background: #80808026; color: black;"><b>Designation</b></td>
                                        <td style="width:30%"><p>{{$desc_name->designation_name}}</p></td>
                                    </tr>
                                    <tr>
                                        <td style="background: #80808026; color: black;"><b style="font-weight:bold;">Branch</b></td>
                                        <td style="width:30%"><p>{{$branch_name->branch_name}}</p></td>
                                        <td style="background: #80808026; color: black;"><b style="font-weight:bold;">Phone No</b></td>
                                        <td style="width:30%"><p>{{$data->phone}}</p></td>
                                    </tr>
                                    <tr>
                                        <td colspan="4"><h2 style="text-align:center;">Distribution History</h2></td>
                                    </tr>
                                    <table class="table table-bordered">
                                        <tr style="background: gray;color: white;">
                                            <td>#</td>
                                            <td>Distribution Date</td>
                                            <td>Item Name</td>
                                            <td>Brand Name</td>
                                            <td>Description</td>
                                        </tr>
                                        @if(isset($distribution_list)!='')
                                            @foreach($distribution_list as $key=>$row)
                                                <tr>
                                                    <td>{{++$key}}</td>
                                                    <td>{{$row->distribution_date}}</td>
                                                    <td>{{$row->item_name}}</td>
                                                    <td>{{$row->brand_name}}</td>
                                                    <td>{{$row->item_desc}}</td>
                                                </tr>
                                            @endforeach
                                        @endif
                                        @if(isset($distribution_list)=='')
                                            <tr>
                                                <td colspan="5" style="text-align:center;"><b style="text-align:center;">No Data Found</b></td>
                                            </tr>
                                        @endif
                                    </table>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @include('admin.include.footer')
        </div>
    </div>
</div>

<script>
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;
    }
</script>

</body>
</html>












